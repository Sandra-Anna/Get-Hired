import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postaservice',
  templateUrl: './postaservice.component.html',
  styleUrls: ['./postaservice.component.css']
})
export class PostaserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
